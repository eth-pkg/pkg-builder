#!/usr/bin/env bash

exec 2>&1

set -e
# Get the directory of the script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the compiled directory path
COMPILED_DIR="$SCRIPT_DIR/hello-world"

# Check if the compiled directory exists
if [ -d "$COMPILED_DIR" ]; then
    java -classpath "$COMPILED_DIR" com.example.HelloWorld.HelloWorld
else
    java -classpath "$SCRIPT_DIR" com.example.HelloWorld.HelloWorld
fi


