#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the compiled directory path
COMPILED_DIR="$SCRIPT_DIR/hello-world"

# Check if the compiled directory exists
if [ -d "$COMPILED_DIR" ]; then
    echo "Compiled directory exists. Running from $COMPILED_DIR"
    java -classpath "$COMPILED_DIR" com.example.HelloWorld.HelloWorld
else
    echo "Compiled directory not found. Running from $SCRIPT_DIR"
    java -classpath "$SCRIPT_DIR" com.example.HelloWorld.HelloWorld
fi


