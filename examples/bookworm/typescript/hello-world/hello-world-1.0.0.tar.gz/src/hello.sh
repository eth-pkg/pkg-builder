#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the compiled directory path
INSTALLED_DIR="$SCRIPT_DIR/hello-world"

if [ -d "$INSTALLED_DIR" ]; then
    echo "Installed directory exists. Running from $INSTALLED_DIR"
    cd "$INSTALLED_DIR" && npm start
else
    echo "Installed directory not found. Running from $SCRIPT_DIR"
    cd "$SCRIPT_DIR" && npm start
fi


